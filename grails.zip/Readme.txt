
grails\build.gradle 
Added mysql-connector-java as runtime dependency

grails\grails-app\conf\application.yml 
Configured MySql DataSource

grails\grails-app\controllers\grails\IndexController.groovy
Added Person scaffold just for test

grails\grails-app\domain\grails\Person.groovy
Database table T_PEOPLE ORM definition

grails\grails-app\domain\grails\PersonEmail.groovy
Database table T_MAILS ORM definition 

grails\grails-app\domain\grails\PersonAddress.groovy
Database table T_ADDRESSES ORM definition