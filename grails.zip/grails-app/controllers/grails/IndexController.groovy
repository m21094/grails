package grails

class IndexController {
    def scaffold = Person
}

