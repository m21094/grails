package grails

class Person {
    
    String fullName
    String pin
    
    static hasMany = [addresses:PersonAddress, emails:PersonEmail]    
    static mapping={
        table 'T_PEOPLE'
        version false
        fullName column: 'FULL_NAME', sqlType: "text", length: 90
        pin column: 'PIN', sqlType: "text", length: 10
        id column: 'ID', length: 10, generator: 'identity'
        addresses column:'T_PEOPLE_ID', lazy: true
        emails  column:'T_PEOPLE_ID', lazy: true
    }
}

