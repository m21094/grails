package grails

class PersonAddress {
        
    String type
    String info
    
    static belongsTo = [person: Person]
    static mapping={
        table 'T_ADDRESSES'
        version false
        type column: 'ADDR_TYPE', sqlType: "text", length: 5
        info column: 'ADDR_INFO', sqlType: "text", length: 300
        id column: 'ID', length: 10, generator: 'identity'
        person column: 'T_PEOPLE_ID', insertable: false, updateable: false
    }
}

