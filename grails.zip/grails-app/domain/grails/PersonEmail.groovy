package grails

class PersonEmail {
    
    String type
    String email
    
    static belongsTo = [person: Person]
    static mapping={
        table 'T_MAILS'
        version false
        type column: 'EMAIL_TYPE', sqlType: "text", length: 5
        email column: 'EMAIL', sqlType: "text", length: 40
        id column: 'ID', length: 10, generator: 'identity'
        person column: 'T_PEOPLE_ID', insertable: false, updateable: false
    }
}

